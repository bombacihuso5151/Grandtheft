# Sunset Bay (Godot 4.3)

Motor kovalamacası ile başlayan, görev sistemli mobil oyun iskeleti.

## Kontroller
Ekrana dokun/sürükle: nişan al ve ateş et. Android geri tuşu: menü.

## Modeller
`python3 tools/make_models.py` -> assets/models/*.obj üretir.
Kendi OBJ/GLB modellerini aynı dosya adlarıyla bu klasöre koyarsan oyun onları kullanır.

## APK
1. Godot 4.3 ile projeyi aç, Project > Export > Android ayarlarını kontrol et.
2. GitHub'a push et, Actions > Build APK > artifact olarak `sunsetbay.apk` iner.
Not: OBB gerekmez, varlıklar APK içine gömülür.
