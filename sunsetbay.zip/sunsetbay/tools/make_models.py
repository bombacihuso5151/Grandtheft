# Yumusak hatli OBJ modeller uretir (arac, motor, surucu, tekerlek).
# Calistir: python3 tools/make_models.py
import math, os

class Mesh:
    def __init__(s): s.v = []; s.f = []
    def strip(s, rings, caps=True):
        n = len(rings[0]); base = len(s.v)
        for r in rings: s.v += r
        for i in range(len(rings) - 1):
            for j in range(n):
                j2 = (j + 1) % n
                A = base + i*n + j; B = base + i*n + j2
                C = base + (i+1)*n + j2; D = base + (i+1)*n + j
                s.f.append((A, B, C)); s.f.append((A, C, D))
        if caps:
            for ring, flip in ((rings[0], True), (rings[-1], False)):
                c = tuple(sum(p[k] for p in ring)/n for k in range(3))
                ci = len(s.v); s.v.append(c); ids = []
                for p in ring: ids.append(len(s.v)); s.v.append(p)
                for j in range(n):
                    a = ids[j]; b = ids[(j+1) % n]
                    s.f.append((ci, b, a) if flip else (ci, a, b))
    def write(s, path):
        nrm = [[0.0, 0.0, 0.0] for _ in s.v]
        for a, b, c in s.f:
            pa, pb, pc = s.v[a], s.v[b], s.v[c]
            u = [pb[i]-pa[i] for i in range(3)]; w = [pc[i]-pa[i] for i in range(3)]
            n = [u[1]*w[2]-u[2]*w[1], u[2]*w[0]-u[0]*w[2], u[0]*w[1]-u[1]*w[0]]
            for idx in (a, b, c):
                for k in range(3): nrm[idx][k] += n[k]
        with open(path, "w") as f:
            f.write("# generated\n")
            for p in s.v: f.write("v %.4f %.4f %.4f\n" % p)
            for n in nrm:
                l = math.sqrt(sum(x*x for x in n)) or 1.0
                f.write("vn %.4f %.4f %.4f\n" % tuple(x/l for x in n))
            for a, b, c in s.f:
                f.write("f %d//%d %d//%d %d//%d\n" % (a+1, a+1, b+1, b+1, c+1, c+1))

def cr(p0, p1, p2, p3, t):
    return 0.5*((2*p1) + (-p0+p2)*t + (2*p0-5*p1+4*p2-p3)*t*t + (-p0+3*p1-3*p2+p3)*t**3)

def smooth(st, sub=4):
    out = []
    for i in range(len(st)-1):
        p0 = st[max(i-1, 0)]; p1 = st[i]; p2 = st[i+1]; p3 = st[min(i+2, len(st)-1)]
        for k in range(sub):
            t = k/sub
            out.append(tuple(cr(p0[q], p1[q], p2[q], p3[q], t) for q in range(len(p1))))
    out.append(st[-1]); return out

def ring(z, hw, yb, yt, x0=0.0, e=2.6, N=22):
    yc = (yb+yt)/2; hh = (yt-yb)/2; pts = []
    for k in range(N):
        th = 2*math.pi*k/N; c, s_ = math.cos(th), math.sin(th)
        pts.append((x0 + hw*math.copysign(abs(c)**(2/e), c), yc + hh*math.copysign(abs(s_)**(2/e), s_), z))
    return pts

def loft(m, stations, x0=0.0, e=2.6):
    m.strip([ring(z, hw, yb, yt, x0, e) for z, hw, yb, yt in smooth(stations)])

def lathe(m, profile, cx=0.0, cy=0.0, cz=0.0, N=28):
    rings = []
    for x, r in profile:
        rings.append([(cx+x, cy + r*math.cos(2*math.pi*k/N), cz + r*math.sin(2*math.pi*k/N)) for k in range(N)])
    m.strip(rings, caps=False)

def sphere(m, c, r, N=16):
    prof = [(-r*math.cos(math.pi*i/N), r*math.sin(math.pi*i/N)) for i in range(N+1)]
    lathe(m, prof, c[0], c[1], c[2], 16)

def tube(m, p0, p1, r0, r1=None, N=10):
    r1 = r0 if r1 is None else r1
    a = [p1[i]-p0[i] for i in range(3)]; l = math.sqrt(sum(x*x for x in a)); a = [x/l for x in a]
    ref = (0, 1, 0) if abs(a[1]) < 0.9 else (1, 0, 0)
    u = [a[1]*ref[2]-a[2]*ref[1], a[2]*ref[0]-a[0]*ref[2], a[0]*ref[1]-a[1]*ref[0]]
    ul = math.sqrt(sum(x*x for x in u)); u = [x/ul for x in u]
    v = [a[1]*u[2]-a[2]*u[1], a[2]*u[0]-a[0]*u[2], a[0]*u[1]-a[1]*u[0]]
    rings = []
    for p, r in ((p0, r0), (p1, r1)):
        rings.append([tuple(p[i] + r*(u[i]*math.cos(2*math.pi*k/N) + v[i]*math.sin(2*math.pi*k/N)) for i in range(3)) for k in range(N)])
    m.strip(rings)

out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "models")
os.makedirs(out, exist_ok=True)

# Tekerlek (yaricap 0.5, X ekseni)
m = Mesh()
lathe(m, [(-0.14, 0.0), (-0.14, 0.44), (-0.10, 0.50), (0.10, 0.50), (0.14, 0.44), (0.14, 0.0)])
m.write(os.path.join(out, "wheel.obj"))

# Araba govde (on = -Z)
m = Mesh()
loft(m, [(-2.2, .55, .38, .56), (-2.05, .82, .32, .70), (-1.3, .95, .28, .84), (0.0, .96, .28, .90),
         (1.4, .96, .28, .90), (2.0, .90, .32, .80), (2.2, .70, .38, .66)], e=3.0)
m.write(os.path.join(out, "car_body.obj"))

# Araba kabin
m = Mesh()
loft(m, [(-0.95, .62, .86, .94), (-0.55, .80, .86, 1.32), (0.55, .80, .86, 1.32), (1.15, .72, .86, 1.12), (1.40, .56, .86, .96)], e=2.4)
m.write(os.path.join(out, "car_cabin.obj"))

# Motor govde
m = Mesh()
loft(m, [(-0.55, .16, .78, .98), (-0.3, .20, .75, 1.08), (0.1, .20, .74, 1.08), (0.4, .14, .76, .98)], e=2.3)
loft(m, [(0.3, .15, .86, .96), (0.7, .17, .84, .98), (1.1, .12, .90, 1.0)], e=2.3)
loft(m, [(-0.35, .18, .32, .72), (0.0, .20, .30, .74), (0.35, .18, .32, .72)], e=3.0)
loft(m, [(0.9, .10, .92, 1.0), (1.3, .06, .96, 1.06)], e=2.3)
for sx in (-0.10, 0.10):
    tube(m, (sx, .35, -.85), (sx, 1.12, -.62), .04)
    tube(m, (sx, .35, .85), (sx, .45, .10), .04)
tube(m, (-.42, 1.12, -.6), (.42, 1.12, -.6), .03)
tube(m, (.22, .42, .92), (.22, .38, 0.0), .06)
sphere(m, (0, .98, -.74), .12)
m.write(os.path.join(out, "bike_body.obj"))

# Surucu (motorun uzerinde)
m = Mesh()
tube(m, (0, 1.0, .45), (0, 1.55, .15), .21, .19)
sphere(m, (0, 1.82, .08), .19)
for sx in (-1, 1):
    tube(m, (sx*.25, 1.50, .15), (sx*.40, 1.13, -.58), .06)
    tube(m, (sx*.18, .98, .45), (sx*.30, .80, -.10), .10, .08)
    tube(m, (sx*.30, .80, -.10), (sx*.28, .42, .12), .08, .06)
m.write(os.path.join(out, "rider.obj"))
print("OBJ modeller:", sorted(os.listdir(out)))
