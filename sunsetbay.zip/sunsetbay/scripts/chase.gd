extends Node3D
# Motor kovalamacası: sürücü motoru kullanır, oyuncu arkadan gelen araçlara ateş eder.
# Ekrana dokun/sürükle = nişan al ve ateş et.

const SEG_LEN := 40.0
const SEG_COUNT := 8
const SPEED := 30.0
const LANES := [-4.0, 0.0, 4.0]
const MODELS := "res://assets/models/"

var m: Dictionary
var segs: Array[Node3D] = []
var fx: Array = []
var enemies: Array = []
var bike: Node3D
var cam: Camera3D
var hud: Control
var rng := RandomNumberGenerator.new()

var state := "play"
var leaving := false
var end_t := 0.0
var t := 0.0
var hp := 100.0
var kills := 0
var spawned := 0
var goal := 10
var firing := false
var crosshair := Vector2(640, 300)
var fire_cd := 0.0
var tracer := 0.0
var hit_t := 0.0
var flash := 0.0
var shake := 0.0
var spawn_cd := 1.5
var line_i := 0
var cur_sub := ""
var sub_until := 0.0

func _ready() -> void:
    m = Game.missions[Game.current]
    goal = m["goal"]
    rng.randomize()
    _setup_env()
    _build_road()
    _build_bike()
    cam = Camera3D.new()
    cam.fov = 70.0
    cam.far = 300.0
    add_child(cam)
    cam.make_current()
    _build_hud()
    crosshair = get_viewport().get_visible_rect().size * 0.5

# ---------- yardımcılar ----------
func _mat(c: Color, rough := 0.7, metal := 0.0, emit := false) -> StandardMaterial3D:
    var mt := StandardMaterial3D.new()
    mt.albedo_color = c
    mt.roughness = rough
    mt.metallic = metal
    if emit:
        mt.emission_enabled = true
        mt.emission = c
        mt.emission_energy_multiplier = 2.5
    return mt

func _box(parent: Node3D, pos: Vector3, size: Vector3, mat: Material) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var b := BoxMesh.new()
    b.size = size
    mi.mesh = b
    mi.material_override = mat
    mi.position = pos
    parent.add_child(mi)
    return mi

# OBJ varsa onu, yoksa kutu kullanır. zero_origin: OBJ içinde konum zaten gömülü.
func _part(parent: Node3D, file: String, fb_size: Vector3, pos: Vector3, mat: Material, zero_origin := false, obj_scale := Vector3.ONE) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var path := MODELS + file
    if ResourceLoader.exists(path):
        mi.mesh = load(path)
        mi.position = Vector3.ZERO if zero_origin else pos
        mi.scale = obj_scale
    else:
        var b := BoxMesh.new()
        b.size = fb_size
        mi.mesh = b
        mi.position = pos
    mi.material_override = mat
    parent.add_child(mi)
    return mi

# ---------- sahne ----------
func _setup_env() -> void:
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sm := ProceduralSkyMaterial.new()
    sm.sky_top_color = Color(0.25, 0.30, 0.58)
    sm.sky_horizon_color = Color(1.0, 0.62, 0.35)
    sm.ground_horizon_color = Color(1.0, 0.62, 0.35)
    sm.ground_bottom_color = Color(0.2, 0.15, 0.15)
    sky.sky_material = sm
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.fog_enabled = true
    env.fog_light_color = Color(1.0, 0.64, 0.42)
    env.fog_density = 0.007
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    var we := WorldEnvironment.new()
    we.environment = env
    add_child(we)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-25, 180, 0)
    sun.light_color = Color(1.0, 0.78, 0.55)
    sun.light_energy = 1.3
    sun.shadow_enabled = Game.quality >= 2
    add_child(sun)

func _build_road() -> void:
    var road_mat := _mat(Color(0.16, 0.16, 0.18), 0.9)
    var walk_mat := _mat(Color(0.45, 0.43, 0.40), 0.95)
    var line_mat := _mat(Color(0.92, 0.86, 0.5), 0.8)
    for i in SEG_COUNT:
        var s := Node3D.new()
        s.position.z = -80.0 + i * SEG_LEN
        add_child(s)
        segs.append(s)
        _box(s, Vector3(0, -0.1, 0), Vector3(12, 0.2, SEG_LEN), road_mat)
        for side in [-1.0, 1.0]:
            _box(s, Vector3(side * 8.0, 0.05, 0), Vector3(4, 0.3, SEG_LEN), walk_mat)
            _box(s, Vector3(side * 6.0, 0.02, 0), Vector3(0.2, 0.04, SEG_LEN), line_mat)
        for lx in [-2.0, 2.0]:
            for d in 2:
                _box(s, Vector3(lx, 0.02, -SEG_LEN * 0.25 + d * SEG_LEN * 0.5), Vector3(0.15, 0.03, 6), line_mat)
        for side in [-1.0, 1.0]:
            var z := -SEG_LEN * 0.5
            while z < SEG_LEN * 0.5:
                var w := rng.randf_range(8.0, 14.0)
                var h := rng.randf_range(8.0, 30.0)
                var c := Color.from_hsv(rng.randf_range(0.0, 0.12), rng.randf_range(0.1, 0.35), rng.randf_range(0.45, 0.8))
                _box(s, Vector3(side * (10.0 + w * 0.5), h * 0.5, z + 6.0), Vector3(w, h, 12), _mat(c, 0.85))
                z += 13.5
            # sokak lambası
            var lamp := _box(s, Vector3(side * 6.4, 2.5, 0), Vector3(0.15, 5, 0.15), _mat(Color(0.2, 0.2, 0.22)))
            _box(lamp, Vector3(-side * 0.4, 2.5, 0), Vector3(0.8, 0.12, 0.3), _mat(Color(1, 0.85, 0.6), 0.5, 0.0, true))

func _build_bike() -> void:
    bike = Node3D.new()
    add_child(bike)
    _part(bike, "bike_body.obj", Vector3(0.35, 0.5, 2.0), Vector3(0, 0.7, 0), _mat(Color(0.75, 0.12, 0.1), 0.3, 0.5), true)
    var tire := _mat(Color(0.05, 0.05, 0.05), 0.9)
    for z in [-0.85, 0.85]:
        _part(bike, "wheel.obj", Vector3(0.25, 0.66, 0.66), Vector3(0, 0.33, z), tire, false, Vector3(0.66, 0.66, 0.66))
    _part(bike, "rider.obj", Vector3(0.45, 0.8, 0.5), Vector3(0, 1.3, 0.3), _mat(Color(0.12, 0.14, 0.2), 0.6), true)
    _box(bike, Vector3(0, 0.98, -0.88), Vector3(0.2, 0.15, 0.06), _mat(Color(1, 0.95, 0.7), 0.3, 0.0, true))

func _make_car(col: Color) -> Node3D:
    var car := Node3D.new()
    _part(car, "car_body.obj", Vector3(1.9, 0.6, 4.4), Vector3(0, 0.6, 0), _mat(col, 0.3, 0.6), true)
    _part(car, "car_cabin.obj", Vector3(1.6, 0.5, 2.0), Vector3(0, 1.1, 0.2), _mat(Color(0.05, 0.07, 0.10), 0.1, 0.8), true)
    var tire := _mat(Color(0.05, 0.05, 0.05), 0.9)
    for x in [-0.95, 0.95]:
        for z in [-1.35, 1.35]:
            _part(car, "wheel.obj", Vector3(0.3, 0.7, 0.7), Vector3(x, 0.35, z), tire, false, Vector3(0.7, 0.7, 0.7))
    var lamp := _mat(Color(1, 0.95, 0.7), 0.3, 0.0, true)
    for x in [-0.65, 0.65]:
        _box(car, Vector3(x, 0.66, -2.12), Vector3(0.32, 0.15, 0.08), lamp)
    return car

func _build_hud() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    hud = Control.new()
    hud.set_anchors_preset(Control.PRESET_FULL_RECT)
    hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hud.draw.connect(_hud_draw)
    layer.add_child(hud)

# ---------- döngü ----------
func _process(delta: float) -> void:
    if Input.is_action_just_pressed("ui_cancel"):
        _to_menu()
        return
    t += delta
    flash = maxf(0.0, flash - delta * 2.0)
    tracer = maxf(0.0, tracer - delta)
    hit_t = maxf(0.0, hit_t - delta)
    shake = maxf(0.0, shake - delta * 3.0)
    for s in segs:
        s.position.z += SPEED * delta
        if s.position.z > 240.0:
            s.position.z -= SEG_LEN * SEG_COUNT
    _update_fx(delta)
    _update_bike_cam()
    if state == "play":
        _update_play(delta)
    else:
        end_t += delta
    hud.queue_redraw()

func _update_bike_cam() -> void:
    bike.position.x = sin(t * 0.7) * 2.8
    bike.rotation.z = cos(t * 0.7) * 0.14
    var sh := Vector3.ZERO
    if Game.shake_on:
        sh = Vector3(rng.randf_range(-1.0, 1.0), rng.randf_range(-1.0, 1.0), 0.0) * shake * 0.08
    cam.position = Vector3(bike.position.x * 0.5 + 1.5, 3.0, -3.4) + sh
    cam.look_at(Vector3(bike.position.x * 0.3, 1.1, 14.0))

func _update_play(delta: float) -> void:
    var lines: Array = m["lines"]
    while line_i < lines.size() and t >= lines[line_i][0]:
        cur_sub = lines[line_i][1]
        sub_until = t + 3.8
        line_i += 1
    spawn_cd -= delta
    if spawn_cd <= 0.0 and enemies.size() < int(m["maxe"]) and spawned < goal:
        _spawn_enemy()
        spawn_cd = m["spawn"]
    var dmg := 0.0
    for e: Dictionary in enemies:
        var n: Node3D = e["n"]
        e["swap"] -= delta
        if e["swap"] <= 0.0:
            e["swap"] = rng.randf_range(1.5, 3.5)
            e["off"] = LANES[rng.randi() % 3]
        var target_z: float = e["hold"] + sin(t * 1.3 + e["phase"]) * 2.0
        n.position.z = move_toward(n.position.z, target_z, e["close"] * delta)
        var tx: float = bike.position.x + float(e["off"]) * 0.6
        var old_x := n.position.x
        n.position.x = lerpf(n.position.x, tx, 1.0 - exp(-1.8 * delta))
        n.rotation.y = lerpf(n.rotation.y, clampf((n.position.x - old_x) * -6.0, -0.35, 0.35), 0.1)
        if n.position.z < 10.0:
            dmg += 7.0 * delta
    if dmg > 0.0:
        hp -= dmg
        flash = 1.0
        shake = maxf(shake, 0.5)
    fire_cd -= delta
    if firing and fire_cd <= 0.0:
        fire_cd = 0.11
        _shoot()
    if hp <= 0.0:
        state = "lose"
        end_t = 0.0
    elif kills >= goal:
        state = "win"
        end_t = 0.0
        Game.complete(m["id"])

func _spawn_enemy() -> void:
    var cols := [Color(0.7, 0.1, 0.1), Color(0.1, 0.2, 0.5), Color(0.15, 0.15, 0.15), Color(0.8, 0.7, 0.1)]
    var car := _make_car(cols[rng.randi() % 4])
    car.position = Vector3(bike.position.x + LANES[rng.randi() % 3], 0.0, 50.0)
    add_child(car)
    spawned += 1
    enemies.append({
        "n": car, "hp": float(m["hp"]), "hold": rng.randf_range(5.5, 11.0),
        "close": rng.randf_range(7.0, 12.0), "off": LANES[rng.randi() % 3],
        "swap": rng.randf_range(1.0, 3.0), "phase": rng.randf() * 6.28,
    })

func _shoot() -> void:
    tracer = 0.06
    shake = maxf(shake, 0.15)
    var best: Dictionary = {}
    var bd := 1e9
    var assist := 0.7 + Game.aim_assist * 0.9
    for e: Dictionary in enemies:
        var n: Node3D = e["n"]
        var p := n.position + Vector3(0, 0.9, 0)
        if cam.is_position_behind(p):
            continue
        var dist := cam.global_position.distance_to(p)
        var rad := clampf(1500.0 / dist, 45.0, 220.0) * assist
        var d := cam.unproject_position(p).distance_to(crosshair)
        if d < rad and d < bd:
            bd = d
            best = e
    if best.is_empty():
        return
    if rng.randf() < 0.85:
        best["hp"] = float(best["hp"]) - 1.0
        hit_t = 0.12
        if best["hp"] <= 0.0:
            _kill(best)

func _kill(e: Dictionary) -> void:
    enemies.erase(e)
    kills += 1
    var n: Node3D = e["n"]
    _explode(n.position + Vector3(0, 1.0, 0))
    var tw := create_tween().set_parallel(true)
    tw.tween_property(n, "position:y", 5.0, 0.6)
    tw.tween_property(n, "rotation:z", 3.0, 0.6)
    tw.tween_property(n, "scale", Vector3.ZERO, 0.6)
    fx.append({"n": n, "vz": SPEED * 0.9, "life": 0.7})
    shake = 1.0

func _explode(pos: Vector3) -> void:
    var p := CPUParticles3D.new()
    p.position = pos
    p.amount = 40
    p.lifetime = 0.9
    p.one_shot = true
    p.explosiveness = 1.0
    p.direction = Vector3.UP
    p.spread = 90.0
    p.initial_velocity_min = 4.0
    p.initial_velocity_max = 10.0
    p.gravity = Vector3(0, -9, 0)
    p.scale_amount_min = 0.5
    p.scale_amount_max = 2.0
    var sm := SphereMesh.new()
    sm.radius = 0.2
    sm.height = 0.4
    sm.radial_segments = 8
    sm.rings = 4
    sm.material = _mat(Color(1.0, 0.5, 0.1), 0.5, 0.0, true)
    p.mesh = sm
    add_child(p)
    p.emitting = true
    fx.append({"n": p, "vz": SPEED, "life": 1.6})

func _update_fx(delta: float) -> void:
    for f: Dictionary in fx.duplicate():
        var n: Node3D = f["n"]
        n.position.z += float(f["vz"]) * delta
        f["life"] -= delta
        if f["life"] <= 0.0:
            n.queue_free()
            fx.erase(f)

# ---------- HUD ----------
func _hud_draw() -> void:
    var f := ThemeDB.fallback_font
    var sz := hud.size
    if flash > 0.0:
        hud.draw_rect(Rect2(Vector2.ZERO, sz), Color(1, 0, 0, flash * 0.3))
    hud.draw_rect(Rect2(20, 20, 220, 16), Color(0, 0, 0, 0.55))
    hud.draw_rect(Rect2(20, 20, 220.0 * clampf(hp / 100.0, 0.0, 1.0), 16), Color(0.85, 0.2, 0.2))
    hud.draw_string(f, Vector2(20, 66), "Düşman: %d / %d" % [kills, goal], HORIZONTAL_ALIGNMENT_LEFT, -1, 26, Color(1, 1, 1))
    var c := crosshair
    var col := Color(1, 0.4, 0.2) if firing else Color(1, 1, 1, 0.9)
    hud.draw_arc(c, 22.0, 0.0, TAU, 32, col, 2.0)
    for d in [Vector2(-1, 0), Vector2(1, 0), Vector2(0, -1), Vector2(0, 1)]:
        hud.draw_line(c + d * 12.0, c + d * 32.0, col, 2.0)
    if hit_t > 0.0:
        hud.draw_line(c + Vector2(-9, -9), c + Vector2(9, 9), Color(1, 0.2, 0.2), 3.0)
        hud.draw_line(c + Vector2(-9, 9), c + Vector2(9, -9), Color(1, 0.2, 0.2), 3.0)
    if tracer > 0.0:
        hud.draw_line(Vector2(sz.x * 0.5, sz.y - 80.0), c, Color(1, 0.9, 0.5, 0.8), 3.0)
    if state == "play":
        if cur_sub != "" and t < sub_until:
            hud.draw_rect(Rect2(sz.x * 0.15, sz.y - 70, sz.x * 0.7, 46), Color(0, 0, 0, 0.55))
            hud.draw_string(f, Vector2(0, sz.y - 38), cur_sub, HORIZONTAL_ALIGNMENT_CENTER, sz.x, 26, Color(1, 1, 1))
        elif t < 4.0 and cur_sub == "":
            hud.draw_string(f, Vector2(0, sz.y - 38), "Dokun ve sürükle: nişan al + ateş et", HORIZONTAL_ALIGNMENT_CENTER, sz.x, 24, Color(1, 1, 1, 0.8))
    else:
        hud.draw_rect(Rect2(Vector2.ZERO, sz), Color(0, 0, 0, 0.55))
        var title := "GÖREV TAMAMLANDI" if state == "win" else "YAKALANDIN"
        hud.draw_string(f, Vector2(0, sz.y * 0.45), title, HORIZONTAL_ALIGNMENT_CENTER, sz.x, 64, Color(1, 0.86, 0.6))
        if end_t > 1.0:
            var sub := "Devam etmek için dokun" if state == "win" else "Tekrar denemek için dokun"
            hud.draw_string(f, Vector2(0, sz.y * 0.45 + 56), sub, HORIZONTAL_ALIGNMENT_CENTER, sz.x, 28, Color(1, 1, 1))

# ---------- girdi ----------
func _input(e: InputEvent) -> void:
    if e is InputEventScreenTouch:
        firing = e.pressed
        crosshair = e.position
        _tap(e.pressed)
    elif e is InputEventScreenDrag:
        crosshair = e.position
    elif e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT:
        firing = e.pressed
        crosshair = e.position
        _tap(e.pressed)
    elif e is InputEventMouseMotion:
        crosshair = e.position

func _tap(pressed: bool) -> void:
    if pressed and state != "play" and end_t > 1.0 and not leaving:
        leaving = true
        if state == "win":
            _to_menu()
        else:
            get_tree().reload_current_scene()

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_GO_BACK_REQUEST:
        _to_menu()

func _to_menu() -> void:
    if leaving and state == "play":
        return
    leaving = true
    get_tree().change_scene_to_file("res://scenes/main_menu.tscn")
