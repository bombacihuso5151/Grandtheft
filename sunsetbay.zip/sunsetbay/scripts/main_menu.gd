extends Control

class MapBG extends Control:
    func _ready() -> void:
        mouse_filter = Control.MOUSE_FILTER_IGNORE
        resized.connect(queue_redraw)

    func _draw() -> void:
        draw_rect(Rect2(Vector2.ZERO, size), Color(0.07, 0.08, 0.10))
        var r := RandomNumberGenerator.new()
        r.seed = 7
        for i in 28:
            var x := r.randf_range(0.0, size.x)
            draw_line(Vector2(x, 0), Vector2(x + r.randf_range(-70, 70), size.y), Color(1, 1, 1, 0.06), r.randf_range(1.0, 4.0))
        for i in 16:
            var y := r.randf_range(0.0, size.y)
            draw_line(Vector2(0, y), Vector2(size.x, y + r.randf_range(-60, 60)), Color(1, 1, 1, 0.06), r.randf_range(1.0, 4.0))
        for i in 6:
            draw_line(Vector2(r.randf_range(0, size.x), 0), Vector2(r.randf_range(0, size.x), size.y), Color(1, 0.7, 0.4, 0.05), 6.0)
        draw_string(ThemeDB.fallback_font, Vector2(30, size.y * 0.55), "LIMAN BÖLGESİ", HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color(1, 1, 1, 0.22))

class Panels extends Control:
    var cols := [Color(0.80, 0.55, 0.35), Color(0.55, 0.65, 0.55), Color(0.72, 0.60, 0.45), Color(0.45, 0.55, 0.68), Color(0.78, 0.45, 0.35)]

    func _ready() -> void:
        mouse_filter = Control.MOUSE_FILTER_IGNORE
        resized.connect(queue_redraw)

    func _draw() -> void:
        var pw := size.x * 0.17
        var h := size.y * 0.60
        var y0 := size.y * 0.09
        var skew := pw * 0.16
        for i in 5:
            var x0 := size.x * 0.5 + (i - 2.5) * pw
            var s := skew if i % 2 == 0 else -skew
            var pts := PackedVector2Array([Vector2(x0 + s, y0), Vector2(x0 + pw + s, y0), Vector2(x0 + pw - s, y0 + h), Vector2(x0 - s, y0 + h)])
            draw_colored_polygon(pts, cols[i])
        # alt kısmı karart
        draw_rect(Rect2(size.x * 0.5 - pw * 2.6, y0 + h * 0.62, pw * 5.2, h * 0.38), Color(0, 0, 0, 0.35))
        # özgün motorcu silüeti
        var d := Color(0.07, 0.07, 0.09)
        var sc := h * 0.30
        var cx := size.x * 0.5
        var cy := y0 + h * 0.80
        draw_arc(Vector2(cx - 1.6 * sc, cy), 0.75 * sc, 0, TAU, 32, d, sc * 0.16)
        draw_arc(Vector2(cx + 1.6 * sc, cy), 0.75 * sc, 0, TAU, 32, d, sc * 0.16)
        var body := PackedVector2Array([
            Vector2(-1.6, 0), Vector2(-1.1, -1.1), Vector2(-0.5, -1.25), Vector2(0.3, -1.0),
            Vector2(1.0, -1.1), Vector2(1.6, 0), Vector2(1.0, -0.7), Vector2(-0.2, -0.55), Vector2(-1.0, -0.6)])
        var bp := PackedVector2Array()
        for p in body:
            bp.append(Vector2(cx + p.x * sc, cy + p.y * sc))
        draw_colored_polygon(bp, d)
        var rider := PackedVector2Array([Vector2(0.9, -1.0), Vector2(0.55, -2.3), Vector2(0.15, -2.2), Vector2(0.3, -1.0)])
        var rp := PackedVector2Array()
        for p in rider:
            rp.append(Vector2(cx - 0.3 * sc + p.x * sc, cy + p.y * sc))
        draw_colored_polygon(rp, d)
        draw_circle(Vector2(cx + 0.2 * sc, cy - 2.5 * sc), 0.28 * sc, d)
        draw_line(Vector2(cx + 0.1 * sc, cy - 1.9 * sc), Vector2(cx - 0.9 * sc, cy - 1.25 * sc), d, sc * 0.12)
        # başlık
        var f := ThemeDB.fallback_font
        draw_string(f, Vector2(0, y0 + h + 72) + Vector2(3, 3), Game.TITLE, HORIZONTAL_ALIGNMENT_CENTER, size.x, 68, Color(0, 0, 0, 0.7))
        draw_string(f, Vector2(0, y0 + h + 72), Game.TITLE, HORIZONTAL_ALIGNMENT_CENTER, size.x, 68, Color(1, 0.86, 0.6))
        draw_string(f, Vector2(0, 38), "KENDİ STÜDYON PRESENTS", HORIZONTAL_ALIGNMENT_CENTER, size.x, 18, Color(1, 1, 1, 0.6))

var overlay: ColorRect

func _ready() -> void:
    set_anchors_preset(Control.PRESET_FULL_RECT)
    var bg := MapBG.new()
    bg.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(bg)
    var pn := Panels.new()
    pn.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(pn)
    var bar := HBoxContainer.new()
    bar.alignment = BoxContainer.ALIGNMENT_CENTER
    bar.add_theme_constant_override("separation", 18)
    bar.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
    bar.offset_top = -100
    bar.offset_bottom = -24
    add_child(bar)
    bar.add_child(_btn("BAŞLA", _on_start))
    bar.add_child(_btn("GÖREVLER", _on_missions))
    bar.add_child(_btn("AYARLAR", _on_settings))

func _btn(text: String, cb: Callable) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = Vector2(210, 62)
    b.add_theme_font_size_override("font_size", 24)
    var sb := StyleBoxFlat.new()
    sb.bg_color = Color(0.08, 0.08, 0.10, 0.88)
    sb.set_border_width_all(2)
    sb.border_color = Color(1, 1, 1, 0.5)
    sb.set_corner_radius_all(6)
    var hv: StyleBoxFlat = sb.duplicate()
    hv.bg_color = Color(0.85, 0.45, 0.15, 0.95)
    b.add_theme_stylebox_override("normal", sb)
    b.add_theme_stylebox_override("hover", hv)
    b.add_theme_stylebox_override("pressed", hv)
    b.add_theme_stylebox_override("disabled", sb)
    b.pressed.connect(cb)
    return b

func _open_overlay(title: String) -> VBoxContainer:
    if overlay:
        overlay.queue_free()
    overlay = ColorRect.new()
    overlay.color = Color(0, 0, 0, 0.78)
    overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(overlay)
    var cc := CenterContainer.new()
    cc.set_anchors_preset(Control.PRESET_FULL_RECT)
    overlay.add_child(cc)
    var pc := PanelContainer.new()
    cc.add_child(pc)
    var mc := MarginContainer.new()
    for s in ["left", "right", "top", "bottom"]:
        mc.add_theme_constant_override("margin_" + s, 24)
    pc.add_child(mc)
    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 12)
    mc.add_child(vb)
    var l := Label.new()
    l.text = title
    l.add_theme_font_size_override("font_size", 32)
    vb.add_child(l)
    return vb

func _close_overlay() -> void:
    if overlay:
        overlay.queue_free()
        overlay = null

func _on_start() -> void:
    var idx := 0
    for i in Game.missions.size():
        if Game.is_unlocked(i) and not Game.done.has(Game.missions[i]["id"]):
            idx = i
            break
    Game.current = idx
    get_tree().change_scene_to_file("res://scenes/chase.tscn")

func _on_missions() -> void:
    var vb := _open_overlay("GÖREVLER")
    for i in Game.missions.size():
        var ms: Dictionary = Game.missions[i]
        var tag := ""
        if Game.done.has(ms["id"]):
            tag = "  [TAMAM]"
        elif not Game.is_unlocked(i):
            tag = "  [KİLİTLİ]"
        var b := _btn("%d. %s%s" % [i + 1, ms["title"], tag], _play_mission.bind(i))
        b.custom_minimum_size = Vector2(480, 56)
        b.disabled = not Game.is_unlocked(i)
        vb.add_child(b)
        var d := Label.new()
        d.text = "    " + ms["desc"]
        d.modulate = Color(1, 1, 1, 0.65)
        vb.add_child(d)
    vb.add_child(_btn("KAPAT", _close_overlay))

func _play_mission(i: int) -> void:
    Game.current = i
    get_tree().change_scene_to_file("res://scenes/chase.tscn")

func _on_settings() -> void:
    var vb := _open_overlay("AYARLAR")
    _slider(vb, "Ses", Game.volume, _set_volume)
    _slider(vb, "Nişan yardımı", Game.aim_assist, _set_aim)
    var l := Label.new()
    l.text = "Grafik kalitesi"
    vb.add_child(l)
    var ob := OptionButton.new()
    ob.add_item("Düşük")
    ob.add_item("Orta")
    ob.add_item("Yüksek")
    ob.selected = Game.quality
    ob.custom_minimum_size = Vector2(420, 44)
    ob.item_selected.connect(_set_quality)
    vb.add_child(ob)
    var cb := CheckButton.new()
    cb.text = "Ekran sarsıntısı"
    cb.button_pressed = Game.shake_on
    cb.toggled.connect(_set_shake)
    vb.add_child(cb)
    vb.add_child(_btn("KAPAT", _close_overlay))

func _slider(vb: VBoxContainer, text: String, val: float, cb: Callable) -> void:
    var l := Label.new()
    l.text = text
    vb.add_child(l)
    var s := HSlider.new()
    s.min_value = 0.0
    s.max_value = 1.0
    s.step = 0.05
    s.value = val
    s.custom_minimum_size = Vector2(420, 32)
    s.value_changed.connect(cb)
    vb.add_child(s)

func _set_volume(v: float) -> void:
    Game.volume = v
    Game.apply_settings()
    Game.save_all()

func _set_aim(v: float) -> void:
    Game.aim_assist = v
    Game.save_all()

func _set_quality(i: int) -> void:
    Game.quality = i
    Game.apply_settings()
    Game.save_all()

func _set_shake(on: bool) -> void:
    Game.shake_on = on
    Game.save_all()
