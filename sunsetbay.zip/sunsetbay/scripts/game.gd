extends Node

const TITLE := "SUNSET BAY"
const SAVE_PATH := "user://save.cfg"

var volume := 0.8
var aim_assist := 0.5
var quality := 1
var shake_on := true
var current := 0
var done := {}

var missions := [
    {
        "id": "m1", "title": "Kaçış", "desc": "Motorla kaçarken peşindeki araçları durdur.",
        "goal": 10, "hp": 10.0, "spawn": 2.6, "maxe": 3,
        "lines": [
            [0.5, "Sürücü: Sıkı tutun, peşimizdeler!"],
            [5.0, "Sürücü: Sol şeritte bir tane var, vur onu!"],
            [11.0, "Sürücü: Mermin bitmesin, şehir sınırına az kaldı!"],
            [19.0, "Sürücü: Aynalara bakma, ateş et!"],
        ],
    },
    {
        "id": "m2", "title": "Gece Devriyesi", "desc": "Devriye araçları seni fark etti. Daha dayanıklılar.",
        "goal": 16, "hp": 13.0, "spawn": 2.0, "maxe": 4,
        "lines": [
            [0.5, "Sürücü: Bu sefer daha fazlalar!"],
            [7.0, "Sürücü: Zırhlı gibi duruyorlar, üstüne üstüne sık!"],
            [16.0, "Sürücü: Yarısını geçtik, devam!"],
        ],
    },
    {
        "id": "m3", "title": "Son Kovalama", "desc": "Şehirden çıkmadan önce son dalga.",
        "goal": 24, "hp": 16.0, "spawn": 1.5, "maxe": 5,
        "lines": [
            [0.5, "Sürücü: Son düzlük! Hepsi peşimizde!"],
            [10.0, "Sürücü: Nefes alma, ateş et!"],
            [22.0, "Sürücü: Köprüyü görüyorum, az kaldı!"],
        ],
    },
]

func _ready() -> void:
    load_all()
    apply_settings()

func apply_settings() -> void:
    AudioServer.set_bus_volume_db(0, linear_to_db(maxf(volume, 0.001)))
    var vp := get_viewport()
    match quality:
        0:
            vp.scaling_3d_scale = 0.6
            vp.msaa_3d = Viewport.MSAA_DISABLED
        1:
            vp.scaling_3d_scale = 0.8
            vp.msaa_3d = Viewport.MSAA_DISABLED
        _:
            vp.scaling_3d_scale = 1.0
            vp.msaa_3d = Viewport.MSAA_2X

func is_unlocked(i: int) -> bool:
    return i == 0 or done.has(missions[i - 1]["id"])

func complete(id: String) -> void:
    done[id] = true
    save_all()

func save_all() -> void:
    var c := ConfigFile.new()
    c.set_value("s", "volume", volume)
    c.set_value("s", "aim", aim_assist)
    c.set_value("s", "quality", quality)
    c.set_value("s", "shake", shake_on)
    c.set_value("p", "done", done.keys())
    c.save(SAVE_PATH)

func load_all() -> void:
    var c := ConfigFile.new()
    if c.load(SAVE_PATH) != OK:
        return
    volume = c.get_value("s", "volume", volume)
    aim_assist = c.get_value("s", "aim", aim_assist)
    quality = c.get_value("s", "quality", quality)
    shake_on = c.get_value("s", "shake", shake_on)
    for k in c.get_value("p", "done", []):
        done[k] = true
